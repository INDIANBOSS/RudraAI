# RudraAI — Starter Website

A responsive dark AI workspace landing page built with plain HTML, CSS and JavaScript. No build step or paid framework required.


## Run locally
Open `index.html` in a browser.

## Deploy to GitHub Pages
1. Create a GitHub repository named `rudraai` (or another name).
2. Upload `index.html`, `style.css`, and `script.js` to the repository root.
3. In repository **Settings → Pages**, choose **Deploy from a branch**.
4. Select `main` and `/ (root)`, then Save.
5. Wait for the Pages deployment and open the URL shown in Settings → Pages.

## Customize
- Edit project links and copy in `index.html`.
- Change colors and spacing in `style.css`.
- This is a static template; no accounts, API keys, or backend are included.
